/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ionic-auto-complete" />
export * from './public-api';
