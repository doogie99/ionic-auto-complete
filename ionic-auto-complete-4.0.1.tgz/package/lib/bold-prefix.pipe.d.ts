import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Bolds the beginning of the matching string in the item
 */
export declare class BoldPrefix implements PipeTransform {
    transform(value: string, keyword: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BoldPrefix, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<BoldPrefix, "boldprefix", true>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BoldPrefix>;
}
