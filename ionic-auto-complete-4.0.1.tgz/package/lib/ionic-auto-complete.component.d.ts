import { DoCheck, EventEmitter, TemplateRef, AfterViewChecked, OnInit } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { IonicAutoCompleteOptions } from './ionic-auto-complete-options.model';
import { IonicAutoCompleteService } from './ionic-auto-complete.service';
import { IonicAutoCompleteStyles } from './ionic-auto-complete-styles.model';
import * as i0 from "@angular/core";
export declare class IonicAutoCompleteComponent implements OnInit, AfterViewChecked, ControlValueAccessor, DoCheck {
    autocompleteOptions: IonicAutoCompleteOptions;
    defaultOpts: IonicAutoCompleteOptions;
    hasFocus: boolean;
    isLoading: boolean;
    focusedOption: number;
    formValue: any;
    promise: any;
    selected: any | any[];
    selection: any;
    showSuggestions: boolean;
    suggestions: any[];
    private onTouchedCallback;
    private onChangeCallback;
    private showListChanged;
    alwaysShowList: boolean;
    autocomplete: string;
    autoFocusSuggestion: boolean;
    clearInvalidInput: boolean;
    disabled: boolean;
    emptyTemplate: TemplateRef<any>;
    exclude: any[];
    frontIcon: false | string;
    hideListOnSelection: boolean;
    keyword: string;
    label: string;
    labelPosition: string;
    listTemplate: TemplateRef<any>;
    location: string;
    maxResults: number;
    maxSelected: number | null;
    multi: boolean;
    name: string;
    provider: IonicAutoCompleteService | Function;
    removeButtonClasses: string;
    removeButtonColor: string;
    removeButtonIcon: string | false;
    removeButtonSlot: string;
    removeDuplicateSuggestions: boolean;
    selectionTemplate: TemplateRef<any>;
    selectOnTabOut: boolean;
    showResultsFirst: boolean;
    styles: IonicAutoCompleteStyles;
    template: TemplateRef<any>;
    useIonInput: boolean;
    autoFocus: EventEmitter<any>;
    autoBlur: EventEmitter<any>;
    blur: EventEmitter<any>;
    focus: EventEmitter<any>;
    ionAutoInput: EventEmitter<string>;
    itemsChange: EventEmitter<any>;
    itemsCleared: EventEmitter<boolean>;
    itemsHidden: EventEmitter<any>;
    itemRemoved: EventEmitter<any>;
    itemSelected: EventEmitter<any>;
    itemsShown: EventEmitter<any>;
    modelChange: EventEmitter<any | any[]>;
    private searchbarElem;
    private inputElem;
    private itemList;
    keywordControl: FormControl;
    set dataProvider(provider: IonicAutoCompleteService | Function);
    set eager(eager: boolean);
    set options(options: IonicAutoCompleteOptions | any);
    get model(): any | any[];
    set model(selected: any | any[]);
    get showList(): boolean;
    set showList(value: boolean);
    /**
     * Handle document click
     *
     * @param event
     *
     * @private
     */
    documentClickHandler(event: Event): void;
    /**
     * Create a new instance
     */
    constructor();
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    ngDoCheck(): void;
    /**
     * Get element's position on screen
     *
     * @param el
     *
     * @private
     */
    private _getPosition;
    private isEventWithinElement;
    /**
     * Get value from form
     *
     * @param selection
     *
     * @private
     */
    getFormValue(selection: any): any;
    clickClear(): void;
    /**
     * Clear current input value
     */
    clearValue(): void;
    /**
     * Get items for auto-complete
     *
     * @param event
     * @param show
     */
    getItems(event?: any, show?: boolean): void;
    /**
     * Get an item's label
     *
     * @param selection
     */
    getLabel(selection: any | any[]): string;
    /**
     * Get menu style
     */
    listStyles(): any;
    private listLocationStyles;
    /**
     * Handles tab key press.
     * If `selectOnTabOut` is `true`, will select currently focused item
     *
     * @param event
     */
    handleTabOut(event: any): void;
    /**
     * Handle tap
     *
     * @param event
     */
    handleTap(event: any): void;
    /**
     * Handle tap when selecting an item
     *
     * @param $event
     * @param suggestion
     */
    handleSelectTap($event: any, suggestion?: any): false;
    /**
     * Hide item list
     */
    hideItemList(): void;
    highlightItem(direction: number): void;
    /**
     * Fired when the input focused
     */
    onFocus(event: any): void;
    /**
     * Fired when the input focused
     */
    onBlur(event: any): void;
    _reflectName(event: any): any;
    /**
     * Register onChangeCallback
     *
     * @param fn
     */
    registerOnChange(fn: Function | false): void;
    /**
     * Register onTouchedCallback
     *
     * @param fn
     */
    registerOnTouched(fn: Function | false): void;
    /**
     * Remove already selected suggestions
     *
     * @param suggestions
     */
    removeDuplicates(suggestions: any[]): any[];
    removeExcluded(suggestions: any[]): any[];
    /**
     * Remove item from selected
     *
     * @param selection
     * @param notify?
     */
    removeItem(selection: any, notify?: boolean): void;
    /**
     * Select item from list
     *
     * @param selection
     **/
    selectItem(selection: any): void;
    /**
     * Set focus of searchbar
     */
    setFocus(): void;
    /**
     * Set suggestions
     *
     * @param suggestions
     * @param show
     */
    setSuggestions(suggestions: any[], show?: boolean): void;
    /**
     * Set current input value
     *
     * Used externally (ie don't delete)
     *
     * @param selection
     */
    setValue(selection: any): void;
    /**
     * Show item list
     */
    showItemList(): void;
    /**
     * Update the model
     */
    updateModel(enteredText: string): void;
    /**
     * Write value
     *
     * @param value
     */
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IonicAutoCompleteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IonicAutoCompleteComponent, "ionic-auto-complete", never, { "alwaysShowList": { "alias": "alwaysShowList"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "autoFocusSuggestion": { "alias": "autoFocusSuggestion"; "required": false; }; "clearInvalidInput": { "alias": "clearInvalidInput"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "emptyTemplate": { "alias": "emptyTemplate"; "required": false; }; "exclude": { "alias": "exclude"; "required": false; }; "frontIcon": { "alias": "frontIcon"; "required": false; }; "hideListOnSelection": { "alias": "hideListOnSelection"; "required": false; }; "keyword": { "alias": "keyword"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "listTemplate": { "alias": "listTemplate"; "required": false; }; "location": { "alias": "location"; "required": false; }; "maxResults": { "alias": "maxResults"; "required": false; }; "maxSelected": { "alias": "maxSelected"; "required": false; }; "multi": { "alias": "multi"; "required": false; }; "name": { "alias": "name"; "required": false; }; "provider": { "alias": "provider"; "required": false; }; "removeButtonClasses": { "alias": "removeButtonClasses"; "required": false; }; "removeButtonColor": { "alias": "removeButtonColor"; "required": false; }; "removeButtonIcon": { "alias": "removeButtonIcon"; "required": false; }; "removeButtonSlot": { "alias": "removeButtonSlot"; "required": false; }; "removeDuplicateSuggestions": { "alias": "removeDuplicateSuggestions"; "required": false; }; "selectionTemplate": { "alias": "selectionTemplate"; "required": false; }; "selectOnTabOut": { "alias": "selectOnTabOut"; "required": false; }; "showResultsFirst": { "alias": "showResultsFirst"; "required": false; }; "styles": { "alias": "styles"; "required": false; }; "template": { "alias": "template"; "required": false; }; "useIonInput": { "alias": "useIonInput"; "required": false; }; "dataProvider": { "alias": "dataProvider"; "required": false; }; "eager": { "alias": "eager"; "required": false; }; "options": { "alias": "options"; "required": false; }; "model": { "alias": "model"; "required": false; }; "showList": { "alias": "showList"; "required": false; }; }, { "autoFocus": "autoFocus"; "autoBlur": "autoBlur"; "blur": "blur"; "focus": "focus"; "ionAutoInput": "ionAutoInput"; "itemsChange": "itemsChange"; "itemsCleared": "itemsCleared"; "itemsHidden": "itemsHidden"; "itemRemoved": "itemRemoved"; "itemSelected": "itemSelected"; "itemsShown": "itemsShown"; "modelChange": "modelChange"; }, never, never, false, never>;
}
