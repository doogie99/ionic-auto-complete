export declare class IonicAutoCompleteStyles {
    list?: {} | undefined;
    listItem?: {} | undefined;
    searchbar?: {} | undefined;
}
