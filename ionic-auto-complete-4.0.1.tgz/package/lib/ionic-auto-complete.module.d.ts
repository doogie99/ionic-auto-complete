import * as i0 from "@angular/core";
import * as i1 from "./ionic-auto-complete.component";
import * as i2 from "@angular/common";
import * as i3 from "@ionic/angular";
import * as i4 from "@angular/forms";
import * as i5 from "./bold-prefix.pipe";
export declare class IonicAutoCompleteComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IonicAutoCompleteComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IonicAutoCompleteComponentModule, [typeof i1.IonicAutoCompleteComponent], [typeof i2.CommonModule, typeof i3.IonicModule, typeof i4.ReactiveFormsModule, typeof i5.BoldPrefix], [typeof i1.IonicAutoCompleteComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IonicAutoCompleteComponentModule>;
}
