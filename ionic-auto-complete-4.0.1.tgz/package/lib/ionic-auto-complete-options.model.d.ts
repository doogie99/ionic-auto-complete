export declare class IonicAutoCompleteOptions {
    animated: boolean;
    color: string | null;
    autocomplete: 'on' | 'off';
    autocorrect: 'on' | 'off';
    cancelButtonIcon: string;
    cancelButtonText: string;
    clearIcon: string;
    clearInput: boolean;
    clearOnEdit: boolean;
    debounce: number;
    mode: 'ios' | 'md';
    noItems: string;
    placeholder: string;
    searchIcon: string;
    showCancelButton: boolean;
    spellcheck: 'on' | 'off';
    type: string;
    value: any | any[];
    constructor();
}
