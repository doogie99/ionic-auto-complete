import * as i0 from '@angular/core';
import { Pipe, Injectable, EventEmitter, TemplateRef, ViewContainerRef, ElementRef, Component, Input, Output, ViewChild, HostListener, NgModule } from '@angular/core';
import * as i3 from '@angular/forms';
import { FormControl, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { Subject, from, Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@ionic/angular';
import { IonicModule } from '@ionic/angular';

class IonicAutoCompleteOptions {
    constructor() {
        this.animated = false;
        this.color = null;
        this.autocomplete = 'off';
        this.autocorrect = 'off';
        this.cancelButtonIcon = 'arrow-round-back';
        this.cancelButtonText = 'Cancel';
        this.clearIcon = 'close-circle';
        this.clearInput = false;
        this.clearOnEdit = false;
        this.debounce = 250;
        this.mode = 'md';
        this.noItems = 'No items found.';
        this.placeholder = 'Search';
        this.searchIcon = 'search';
        this.showCancelButton = false;
        this.spellcheck = 'off';
        this.type = 'search';
    }
}

class IonicAutoCompleteStyles {
    constructor() {
        this.list = {};
        this.listItem = {};
        this.searchbar = {};
    }
}

/**
 * Bolds the beginning of the matching string in the item
 */
class BoldPrefix {
    transform(value, keyword) {
        if (!keyword) {
            return value;
        }
        let escaped_keyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return value.replace(new RegExp(escaped_keyword, 'gi'), function (str) {
            return str.bold();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: BoldPrefix, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.1.0", ngImport: i0, type: BoldPrefix, isStandalone: true, name: "boldprefix" }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: BoldPrefix }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: BoldPrefix, decorators: [{
            type: Pipe,
            args: [{
                    name: 'boldprefix',
                }]
        }, {
            type: Injectable
        }] });

class IonicAutoCompleteComponent {
    set dataProvider(provider) {
        if (typeof provider !== 'undefined') {
            this.provider = provider;
            if (typeof this.selected !== 'undefined') {
                this.keyword = this.getLabel(this.selected);
            }
        }
    }
    set eager(eager) {
        if (eager) {
            this.getItems(null, false);
        }
    }
    set options(options) {
        this.autocompleteOptions = new IonicAutoCompleteOptions();
        const keys = Object.keys(options);
        const keysLength = keys.length;
        for (let i = 0; i < keysLength; i++) {
            const key = keys[i];
            if (typeof options[key] !== 'undefined') {
                this.autocompleteOptions[key] = options[key];
            }
        }
        if (typeof this.selected === 'undefined') {
            if (typeof this.autocompleteOptions.value !== 'undefined') {
                this.selected = this.autocompleteOptions.value;
            }
            else {
                if (this.multi) {
                    this.selected = [];
                }
                else {
                    this.selected = null;
                }
            }
            this.keyword = this.getLabel(this.selected);
        }
        if (this.autocompleteOptions.autocomplete) {
            this.autocomplete = this.autocompleteOptions.autocomplete;
        }
        else {
            this.autocomplete = 'off';
        }
    }
    get model() {
        let model = this.selected;
        if (!this.multi && typeof this.selected.length !== 'undefined') {
            if (this.selected.length === 0) {
                model = null;
            }
            else {
                model = this.selected[0];
            }
        }
        return model;
    }
    set model(selected) {
        this.selected = selected;
    }
    get showList() {
        return this.showSuggestions;
    }
    set showList(value) {
        if (typeof value === 'undefined') {
            return;
        }
        if (this.showSuggestions === value) {
            return;
        }
        this.showSuggestions = value === true;
        this.showListChanged = true;
    }
    /**
     * Handle document click
     *
     * @param event
     *
     * @private
     */
    documentClickHandler(event) {
        if (this.isEventWithinElement(this.searchbarElem, event)
            || this.isEventWithinElement(this.inputElem, event)
            || (this.isEventWithinElement(this.itemList, event))) {
            this.setSuggestions(this.suggestions);
        }
        else {
            this.hideItemList();
        }
    }
    /**
     * Create a new instance
     */
    constructor() {
        this.autocompleteOptions = new IonicAutoCompleteOptions();
        this.hasFocus = false;
        this.isLoading = false;
        this.focusedOption = -1;
        this.promise = null;
        this.showSuggestions = false;
        this.onTouchedCallback = false;
        this.onChangeCallback = false;
        this.showListChanged = false;
        this.alwaysShowList = false;
        this.autoFocusSuggestion = true;
        this.clearInvalidInput = true;
        this.disabled = false;
        this.exclude = [];
        this.frontIcon = false;
        this.hideListOnSelection = true;
        this.label = '';
        this.labelPosition = 'fixed';
        this.location = 'auto';
        this.maxResults = 8;
        this.maxSelected = null;
        this.multi = false;
        this.name = '';
        this.removeButtonClasses = '';
        this.removeButtonColor = 'primary';
        this.removeButtonIcon = 'close-circle';
        this.removeButtonSlot = 'end';
        this.removeDuplicateSuggestions = true;
        this.selectOnTabOut = true;
        this.styles = new IonicAutoCompleteStyles;
        this.useIonInput = false;
        this.keywordControl = new FormControl();
        this.autoBlur = new EventEmitter();
        this.autoFocus = new EventEmitter();
        this.blur = new EventEmitter();
        this.focus = new EventEmitter();
        this.ionAutoInput = new EventEmitter();
        this.itemsChange = new EventEmitter();
        this.itemsCleared = new EventEmitter();
        this.itemsHidden = new EventEmitter();
        this.itemRemoved = new EventEmitter();
        this.itemSelected = new EventEmitter();
        this.itemsShown = new EventEmitter();
        this.modelChange = new EventEmitter();
        this.keyword = '';
        this.suggestions = [];
    }
    ngOnInit() {
        this.keywordControl.valueChanges.subscribe(value => {
            this.updateModel(value);
        });
    }
    ngAfterViewChecked() {
        if (this.showListChanged) {
            this.showListChanged = false;
            this.showSuggestions ? this.itemsShown.emit() : this.itemsHidden.emit();
        }
    }
    ngDoCheck() {
        if (!this.hasFocus) {
            if (this.clearInvalidInput && (this.selected === null || this.multi)) {
                if (this.keyword !== '') {
                    this.keyword = '';
                }
                if (this.inputElem && this.inputElem.nativeElement) {
                    if (this.inputElem.nativeElement.children && this.inputElem.nativeElement.children.length !== 0) {
                        if (this.inputElem.nativeElement.children[0].children && this.inputElem.nativeElement.children[0].children.length !== 0) {
                            if (this.inputElem.nativeElement.children[0].children[0].value) {
                                this.inputElem.nativeElement.children[0].children[0].value = '';
                            }
                        }
                    }
                }
                if (this.searchbarElem && this.searchbarElem.nativeElement) {
                    if (this.searchbarElem.nativeElement.children && this.searchbarElem.nativeElement.children.length !== 0) {
                        if (this.searchbarElem.nativeElement.children[0].children) {
                            if (this.searchbarElem.nativeElement.children[0].children.length !== 0) {
                                if (this.searchbarElem.nativeElement.children[0].children[0].value) {
                                    this.searchbarElem.nativeElement.children[0].children[0].value = '';
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    /**
     * Get element's position on screen
     *
     * @param el
     *
     * @private
     */
    _getPosition(el) {
        let xPos = 0;
        let yPos = 0;
        while (el) {
            if (el.tagName === 'BODY') {
                const xScroll = el.scrollLeft || document.documentElement.scrollLeft;
                const yScroll = el.scrollTop || document.documentElement.scrollTop;
                xPos += (el.offsetLeft - xScroll + el.clientLeft);
                yPos += (el.offsetTop - yScroll + el.clientTop);
            }
            else {
                xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
                yPos += (el.offsetTop - el.scrollTop + el.clientTop);
            }
            el = el.offsetParent;
        }
        return {
            x: xPos,
            y: yPos
        };
    }
    isEventWithinElement(elementOrTemplate, event) {
        if (typeof elementOrTemplate === 'undefined') {
            return false;
        }
        let element;
        if (elementOrTemplate instanceof TemplateRef) {
            element = elementOrTemplate.elementRef;
        }
        else if (elementOrTemplate instanceof ViewContainerRef) {
            element = elementOrTemplate.element.nativeElement;
        }
        else {
            element = elementOrTemplate;
        }
        return element
            && element.nativeElement
            && element.nativeElement.contains(event.target);
    }
    /**
     * Get value from form
     *
     * @param selection
     *
     * @private
     */
    getFormValue(selection) {
        if (typeof this.provider === 'undefined') {
            return null;
        }
        if (selection == null || typeof this.provider === 'function') {
            return null;
        }
        let attr = this.provider.formValueAttribute == null ?
            this.provider.labelAttribute : this.provider.formValueAttribute;
        if (typeof selection === 'object' && attr) {
            return selection[attr];
        }
        return selection;
    }
    clickClear() {
        this.clearValue();
        this.hideItemList();
        this.itemsCleared.emit(true);
    }
    /**
     * Clear current input value
     */
    clearValue() {
        this.keyword = '';
        this.selection = null;
        this.formValue = null;
        if (this.focusedOption > 0) {
            this.focusedOption = this.focusedOption - 1;
        }
        return;
    }
    /**
     * Get items for auto-complete
     *
     * @param event
     * @param show
     */
    getItems(event, show) {
        this.isLoading = true;
        if (this.promise) {
            clearTimeout(this.promise);
        }
        this.promise = setTimeout(() => {
            if (event) {
                console.log(event);
                this.keyword = event.detail.value;
            }
            let result;
            if (this.showResultsFirst && this.keyword.trim() === '') {
                this.keyword = '';
            }
            if (typeof this.provider === 'function') {
                result = this.provider(this.keyword);
                this.setSuggestions(result, show);
                this.isLoading = false;
            }
            else {
                result = this.provider.getResults(this.keyword);
                if (result instanceof Subject) {
                    result = result.asObservable();
                }
                else if (result instanceof Promise) {
                    result = from(result);
                }
                if (result instanceof Observable) {
                    result.pipe(finalize(() => {
                        this.isLoading = false;
                    })).subscribe((results) => {
                        this.setSuggestions(results, show);
                    }, (error) => console.error(error));
                }
                else {
                    this.setSuggestions(result, show);
                    this.isLoading = false;
                }
            }
            this.ionAutoInput.emit(this.keyword);
        }, this.autocompleteOptions.debounce);
    }
    /**
     * Get an item's label
     *
     * @param selection
     */
    getLabel(selection) {
        if (typeof this.provider === 'undefined') {
            return '';
        }
        if (selection == null || typeof this.provider === 'function') {
            return '';
        }
        let attr = this.provider.formValueAttribute == null ?
            this.provider.labelAttribute : this.provider.formValueAttribute;
        let value = selection;
        if (this.provider.getItemLabel) {
            value = this.provider.getItemLabel(value);
        }
        if (!this.multi && typeof value !== 'undefined' && Object.prototype.toString.call(value) === '[object Array]') {
            if (value.length === 0) {
                return '';
            }
            else {
                value = value[0];
            }
        }
        if (typeof value === 'object' && attr) {
            return value[attr] || '';
        }
        return value || '';
    }
    /**
     * Get menu style
     */
    listStyles() {
        const listLocationStyles = this.listLocationStyles();
        return { ...listLocationStyles, ...this.styles.list };
    }
    listLocationStyles() {
        let location = this.location;
        if (this.location === 'auto') {
            const elementY = this._getPosition(this.searchbarElem.nativeElement).y;
            const windowY = window.innerHeight;
            if (elementY > windowY - elementY) {
                location = 'top';
            }
            else {
                location = 'bottom';
            }
        }
        if (location === 'bottom') {
            return {};
        }
        else {
            return {
                'bottom': '37px'
            };
        }
    }
    /**
     * Handles tab key press.
     * If `selectOnTabOut` is `true`, will select currently focused item
     *
     * @param event
     */
    handleTabOut(event) {
        if (this.selectOnTabOut && this.suggestions.length !== 0) {
            if (this.focusedOption !== -1) {
                this.selectItem(this.suggestions[this.focusedOption]);
            }
            else {
                this.hideItemList();
            }
        }
        else {
            this.hideItemList();
        }
        this.onBlur(event);
    }
    /**
     * Handle tap
     *
     * @param event
     */
    handleTap(event) {
        if (this.showResultsFirst || this.keyword.length > 0) {
            this.getItems();
        }
    }
    /**
     * Handle tap when selecting an item
     *
     * @param $event
     * @param suggestion
     */
    handleSelectTap($event, suggestion) {
        if (typeof suggestion !== 'undefined') {
            this.selectItem(suggestion);
            if ($event.srcEvent) {
                if ($event.srcEvent.stopPropagation) {
                    $event.srcEvent.stopPropagation();
                }
                if ($event.srcEvent.preventDefault) {
                    $event.srcEvent.preventDefault();
                }
            }
            else if ($event.preventDefault) {
                $event.preventDefault();
            }
        }
        return false;
    }
    /**
     * Hide item list
     */
    hideItemList() {
        if (this.showSuggestions === false && this.alwaysShowList === false) {
            this.showListChanged = true;
        }
        this.showSuggestions = this.alwaysShowList;
        this.focusedOption = -1;
    }
    highlightItem(direction) {
        if (this.showSuggestions === false) {
            this.showItemList();
        }
        let max = this.suggestions.length - 1;
        if (max > this.maxResults) {
            max = this.maxResults - 1;
        }
        if (direction < 0) {
            if (this.focusedOption === -1 || this.focusedOption === max) {
                this.focusedOption = 0;
            }
            else {
                this.focusedOption++;
            }
        }
        else if (direction > 0) {
            if (this.focusedOption === -1 || this.focusedOption === 0) {
                this.focusedOption = max;
            }
            else {
                this.focusedOption--;
            }
        }
    }
    /**
     * Fired when the input focused
     */
    onFocus(event) {
        this.hasFocus = true;
        this.getItems();
        event = this._reflectName(event);
        this.autoFocus.emit(event);
        this.focus.emit(event);
    }
    /**
     * Fired when the input focused
     */
    onBlur(event) {
        this.hasFocus = false;
        event = this._reflectName(event);
        this.autoBlur.emit(event);
        this.blur.emit(event);
    }
    _reflectName(event) {
        if (typeof event.srcElement.attributes['ng-reflect-name'] === 'object') {
            event.srcElement.name = event.srcElement.attributes['ng-reflect-name'].value;
        }
        return event;
    }
    /**
     * Register onChangeCallback
     *
     * @param fn
     */
    registerOnChange(fn) {
        this.onChangeCallback = fn;
    }
    /**
     * Register onTouchedCallback
     *
     * @param fn
     */
    registerOnTouched(fn) {
        this.onTouchedCallback = fn;
    }
    /**
     * Remove already selected suggestions
     *
     * @param suggestions
     */
    removeDuplicates(suggestions) {
        const selectedCount = this.selected ? this.selected.length : 0;
        const suggestionCount = suggestions.length;
        for (let i = 0; i < selectedCount; i++) {
            const selectedLabel = this.getLabel(this.selected[i]);
            for (let j = 0; j < suggestionCount; j++) {
                const suggestedLabel = this.getLabel(suggestions[j]);
                if (selectedLabel === suggestedLabel) {
                    suggestions.splice(j, 1);
                }
            }
        }
        return suggestions;
    }
    removeExcluded(suggestions) {
        const excludedCount = this.exclude.length;
        for (let i = 0; i < excludedCount; i++) {
            let excludeLabel = this.exclude[i];
            if (typeof excludeLabel === 'object') {
                excludeLabel = this.getLabel(excludeLabel);
            }
            const suggestionCount = suggestions.length;
            for (let j = 0; j < suggestionCount; j++) {
                const suggestedLabel = this.getLabel(suggestions[j]);
                if (excludeLabel === suggestedLabel) {
                    suggestions.splice(j, 1);
                    break;
                }
            }
        }
        return suggestions;
    }
    /**
     * Remove item from selected
     *
     * @param selection
     * @param notify?
     */
    removeItem(selection, notify) {
        const count = this.selected ? this.selected.length : 0;
        for (let i = 0; i < count; i++) {
            const item = this.selected[i];
            const selectedLabel = this.getLabel(selection);
            const itemLabel = this.getLabel(item);
            if (selectedLabel === itemLabel) {
                this.selected.splice(i, 1);
            }
        }
        notify = typeof notify === 'undefined' ? true : notify;
        if (notify) {
            this.itemRemoved.emit(selection);
            this.itemsChange.emit(this.selected);
        }
        this.modelChange.emit(this.selected);
    }
    /**
     * Select item from list
     *
     * @param selection
     **/
    selectItem(selection) {
        this.keyword = this.getLabel(selection);
        this.formValue = this.getFormValue(selection);
        this.updateModel(this.formValue);
        if (this.hideListOnSelection) {
            this.hideItemList();
        }
        if (this.multi) {
            if (this.maxSelected === null || this.selected.length <= this.maxSelected) {
                this.clearValue();
                this.selected.push(selection);
                this.itemsChange.emit(this.selected);
            }
            else {
                return;
            }
        }
        else {
            this.selection = selection;
            this.selected = [selection];
            this.itemsChange.emit(selection);
        }
        this.itemSelected.emit(selection);
        this.modelChange.emit(this.selected);
    }
    /**
     * Set focus of searchbar
     */
    setFocus() {
        if (this.useIonInput && this.inputElem) {
            this.inputElem.nativeElement.setFocus();
        }
        else if (this.searchbarElem) {
            this.searchbarElem.nativeElement.setFocus();
        }
    }
    /**
     * Set suggestions
     *
     * @param suggestions
     * @param show
     */
    setSuggestions(suggestions, show) {
        if (this.removeDuplicateSuggestions) {
            suggestions = this.removeDuplicates(suggestions);
            suggestions = this.removeExcluded(suggestions);
        }
        this.suggestions = suggestions;
        if (show || typeof show === 'undefined') {
            this.showItemList();
        }
        if (this.autoFocusSuggestion) {
            if (this.suggestions.length !== 0) {
                this.focusedOption = 0;
            }
        }
    }
    /**
     * Set current input value
     *
     * Used externally (ie don't delete)
     *
     * @param selection
     */
    setValue(selection) {
        this.formValue = this.getFormValue(selection);
        this.keyword = this.getLabel(selection);
        return;
    }
    /**
     * Show item list
     */
    showItemList() {
        if (this.showSuggestions === false) {
            this.showListChanged = true;
        }
        this.showSuggestions = true;
    }
    /**
     * Update the model
     */
    updateModel(enteredText) {
        if (enteredText !== this.formValue) {
            this.formValue = enteredText;
            if (!this.multi) {
                this.selected = null;
            }
        }
        if (this.onChangeCallback) {
            this.onChangeCallback(this.formValue);
        }
        this.modelChange.emit(this.selected);
    }
    /**
     * Write value
     *
     * @param value
     */
    writeValue(value) {
        if (value !== this.selection) {
            this.selection = value || null;
            this.formValue = this.getFormValue(this.selection);
            this.keyword = this.getLabel(this.selection);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.0", type: IonicAutoCompleteComponent, isStandalone: false, selector: "ionic-auto-complete", inputs: { alwaysShowList: "alwaysShowList", autocomplete: "autocomplete", autoFocusSuggestion: "autoFocusSuggestion", clearInvalidInput: "clearInvalidInput", disabled: "disabled", emptyTemplate: "emptyTemplate", exclude: "exclude", frontIcon: "frontIcon", hideListOnSelection: "hideListOnSelection", keyword: "keyword", label: "label", labelPosition: "labelPosition", listTemplate: "listTemplate", location: "location", maxResults: "maxResults", maxSelected: "maxSelected", multi: "multi", name: "name", provider: "provider", removeButtonClasses: "removeButtonClasses", removeButtonColor: "removeButtonColor", removeButtonIcon: "removeButtonIcon", removeButtonSlot: "removeButtonSlot", removeDuplicateSuggestions: "removeDuplicateSuggestions", selectionTemplate: "selectionTemplate", selectOnTabOut: "selectOnTabOut", showResultsFirst: "showResultsFirst", styles: "styles", template: "template", useIonInput: "useIonInput", dataProvider: "dataProvider", eager: "eager", options: "options", model: "model", showList: "showList" }, outputs: { autoFocus: "autoFocus", autoBlur: "autoBlur", blur: "blur", focus: "focus", ionAutoInput: "ionAutoInput", itemsChange: "itemsChange", itemsCleared: "itemsCleared", itemsHidden: "itemsHidden", itemRemoved: "itemRemoved", itemSelected: "itemSelected", itemsShown: "itemsShown", modelChange: "modelChange" }, host: { listeners: { "document:click": "documentClickHandler($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: IonicAutoCompleteComponent,
                multi: true
            }
        ], viewQueries: [{ propertyName: "searchbarElem", first: true, predicate: ["searchbarElem"], descendants: true, read: ElementRef }, { propertyName: "inputElem", first: true, predicate: ["inputElem"], descendants: true, read: ElementRef }, { propertyName: "itemList", first: true, predicate: ["itemList"], descendants: true, read: ElementRef }], ngImport: i0, template: "<ng-template #defaultSelection\n    let-attrs=\"attrs\">\n    <ion-chip class=\"{{ attrs.removeButtonClasses }}\"\n        [color]=\"attrs.removeButtonColor\"\n        [outline]=\"true\">\n        <ion-icon *ngIf=\"frontIcon\"\n            [name]=\"frontIcon\"\n            [slot]=\"'start'\"\n            color=\"primary\"></ion-icon>\n\n        <ion-label>{{ attrs.label }}</ion-label>\n\n        <ion-icon *ngIf=\"attrs.removeButtonIcon\"\n            [name]=\"attrs.removeButtonIcon\"\n            [slot]=\"attrs.removeButtonSlot\"></ion-icon>\n    </ion-chip>\n</ng-template>\n\n<div *ngIf=\"multi\">\n    <div *ngFor=\"let item of selected\"\n        class=\"selected-items\"\n        (click)=\"removeItem(item)\">\n        <ng-template [ngTemplateOutlet]=\"selectionTemplate || defaultSelection\"\n            [ngTemplateOutletContext]=\"{\n                            attrs: {\n                              data:                item,\n                              label:               getLabel(item),\n                              removeButtonClasses: removeButtonClasses,\n                              removeButtonColor:   removeButtonColor,\n                              removeButtonIcon:    removeButtonIcon,\n                              removeButtonSlot:    removeButtonSlot\n                            }\n                         }\"></ng-template>\n    </div>\n</div>\n\n<ion-label *ngIf=\"label.length !== 0\"\n    [position]=\"labelPosition\">{{ label }}</ion-label>\n\n<ion-input #inputElem\n    [autocomplete]=\"autocomplete\"\n    [name]=\"name\"\n    (ionInput)=\"getItems($event)\"\n    (tap)=\"handleTap($event)\"\n    [formControl]=\"keywordControl\"\n    [placeholder]=\"autocompleteOptions.placeholder == null ? defaultOpts.placeholder : autocompleteOptions.placeholder\"\n    [type]=\"autocompleteOptions.type == null ? defaultOpts.type : autocompleteOptions.type\"\n    [clearOnEdit]=\"autocompleteOptions.clearOnEdit == null ? defaultOpts.clearOnEdit : autocompleteOptions.clearOnEdit\"\n    [clearInput]=\"autocompleteOptions.clearInput == null ? defaultOpts.clearInput : autocompleteOptions.clearInput\"\n    [color]=\"autocompleteOptions.color == null ? null : autocompleteOptions.color\"\n    [mode]=\"autocompleteOptions.mode == null ? defaultOpts.mode : autocompleteOptions.mode\"\n    [disabled]=\"disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected)\"\n    [ngClass]=\"{ 'hidden': !useIonInput, 'loading': isLoading }\"\n    [ngStyle]=\"styles.searchbar\"\n    (keydown.tab)=\"handleTabOut($event)\"\n    (keydown.shift.tab)=\"hideItemList()\"\n    (keyup.arrowDown)=\"highlightItem(-1)\"\n    (keyup.arrowUp)=\"highlightItem(1)\"\n    (keyup.enter)=\"handleSelectTap($event, suggestions[focusedOption])\"\n    (keyup.escape)=\"hideItemList()\"\n    (ionFocus)=\"onFocus($event)\"\n    (ionBlur)=\"onBlur($event)\"></ion-input>\n\n<ion-searchbar #searchbarElem\n    [autocomplete]=\"autocomplete\"\n    [name]=\"name\"\n    [animated]=\"autocompleteOptions.animated == null ? defaultOpts.animated : autocompleteOptions.animated\"\n    (ionInput)=\"getItems($event)\"\n    (tap)=\"handleTap($event)\"\n    [formControl]=\"keywordControl\"\n    [cancelButtonIcon]=\"autocompleteOptions.cancelButtonIcon == null ? defaultOpts.cancelButtonIcon : autocompleteOptions.cancelButtonIcon\"\n    [cancelButtonText]=\"autocompleteOptions.cancelButtonText == null ? defaultOpts.cancelButtonText : autocompleteOptions.cancelButtonText\"\n    [clearIcon]=\"autocompleteOptions.clearIcon == null ? defaultOpts.clearIcon : autocompleteOptions.clearIcon\"\n    [color]=\"autocompleteOptions.color == null ? null : autocompleteOptions.color\"\n    [showCancelButton]=\"autocompleteOptions.showCancelButton == null ?\n                                        (defaultOpts.showCancelButton ? 'always' : 'never') :\n                                        (autocompleteOptions.showCancelButton ? 'always' : 'never')\"\n    [debounce]=\"autocompleteOptions.debounce == null ? defaultOpts.debounce : autocompleteOptions.debounce\"\n    [placeholder]=\"autocompleteOptions.placeholder == null ? defaultOpts.placeholder : autocompleteOptions.placeholder\"\n    [autocorrect]=\"autocompleteOptions.autocorrect == null ? defaultOpts.autocorrect : autocompleteOptions.autocorrect\"\n    [mode]=\"autocompleteOptions.mode == null ? defaultOpts.mode : autocompleteOptions.mode\"\n    [searchIcon]=\"autocompleteOptions.searchIcon == null ? defaultOpts.searchIcon : autocompleteOptions.searchIcon\"\n    [spellcheck]=\"autocompleteOptions.spellcheck == null ? defaultOpts.spellcheck : autocompleteOptions.spellcheck\"\n    [type]=\"autocompleteOptions.type == null ? defaultOpts.type : autocompleteOptions.type\"\n    [ngClass]=\"{ 'hidden': useIonInput, 'loading': isLoading, 'disabled': disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected) }\"\n    [ngStyle]=\"styles.searchbar\"\n    (keydown.tab)=\"handleTabOut($event)\"\n    (keydown.shift.tab)=\"hideItemList()\"\n    (keyup.arrowDown)=\"highlightItem(-1)\"\n    (keyup.arrowUp)=\"highlightItem(1)\"\n    (keyup.enter)=\"handleSelectTap($event, suggestions[focusedOption])\"\n    (keyup.escape)=\"hideItemList()\"\n    (ionClear)=\"clickClear()\"\n    (ionFocus)=\"onFocus($event)\"\n    (ionBlur)=\"onBlur($event)\"></ion-searchbar>\n\n<ng-template #defaultTemplate\n    let-attrs=\"attrs\">\n    <span [innerHTML]='attrs.label | boldprefix:attrs.keyword'></span>\n</ng-template>\n\n<ng-template #defaultEmptyTemplate\n    let-attrs=\"attrs\"\n    class=\"ion-text-center\">\n    {{ autocompleteOptions.noItems }}\n</ng-template>\n\n<ng-template [ngTemplateOutlet]=\"listTemplate || defaultList\"\n    [ngTemplateOutletContext]=\"{\n                        attrs: {\n                            data:            suggestions,\n                            keyword:         keyword,\n                            maxResults:      maxResults,\n                            maxSelected:     maxSelected,\n                            selected:        selected,\n                            showSuggestions: showSuggestions\n                          }\n                        }\"></ng-template>\n\n<ng-template #defaultList\n    let-attrs=\"attrs\">\n    <ul *ngIf=\"!(disabled || (attrs.maxSelected !== null && attrs.selected.length >= attrs.maxSelected)) && attrs.data.length > 0 && attrs.showSuggestions\"\n        #itemList\n        [ngStyle]=\"listStyles()\">\n        <li *ngFor=\"let suggestion of attrs.data| slice:0 : attrs.maxResults; let index = index\"\n            [ngClass]=\"{ 'focus': focusedOption === index }\"\n            [ngStyle]=\"styles.listItem\"\n            (mouseenter)=\"focusedOption = index\"\n            (click)=\"handleSelectTap($event, suggestion)\"\n            (tap)=\"handleSelectTap($event, suggestion)\">\n            <ng-template [ngTemplateOutlet]=\"template || defaultTemplate\"\n                [ngTemplateOutletContext]=\"{\n                            attrs:{\n                              data:               suggestion,\n                              label:              getLabel(suggestion),\n                              keyword:            keyword,\n                              formValue:          getFormValue(suggestion),\n                              labelAttribute:     getLabel(suggestion),\n                              formValueAttribute: getFormValue(suggestion)\n                            }\n                         }\"></ng-template>\n        </li>\n    </ul>\n\n    <ul *ngIf=\"!isLoading && suggestions.length === 0 && showSuggestions\"\n        [ngStyle]=\"listStyles()\">\n        <li [ngStyle]=\"styles.listItem\">\n            <ng-template [ngTemplateOutlet]=\"emptyTemplate || defaultEmptyTemplate\"\n                [ngTemplateOutletContext]=\"{\n                        attrs:{\n                          keyword: keyword\n                        }\n                     }\"></ng-template>\n        </li>\n    </ul>\n</ng-template>", styles: ["ion-auto-complete{overflow:hidden!important;width:90vw;display:inline-block}ion-auto-complete ion-searchbar{padding:1px!important}ion-auto-complete .disabled input.searchbar-input{pointer-events:none;cursor:default}ion-auto-complete ul{position:absolute;width:90vw;margin-top:0;background:#fff;list-style-type:none;padding:0;left:16px;z-index:999;box-shadow:0 2px 2px #00000024,0 3px 1px -2px #0003,0 1px 5px #0000001f}ion-auto-complete ul li{padding:15px;border-bottom:1px solid #c1c1c1}ion-auto-complete ul li span{pointer-events:none}ion-auto-complete ul ion-auto-complete-item{height:40px;width:100%}ion-auto-complete ul li:last-child{border:none}ion-auto-complete ul li:focus,ion-auto-complete ul li.focus{cursor:pointer;background:#f1f1f1}ion-auto-complete .hidden{display:none}ion-auto-complete .loading input.searchbar-input{background:#fff url(/assets/loading.gif) no-repeat right 4px center;background-size:25px 25px}ion-auto-complete .searchbar-clear-button.sc-ion-searchbar-md{right:34px}ion-auto-complete .selected-items{float:left}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i2.IonChip, selector: "ion-chip", inputs: ["color", "disabled", "mode", "outline"] }, { kind: "component", type: i2.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: i2.IonInput, selector: "ion-input", inputs: ["autocapitalize", "autocomplete", "autocorrect", "autofocus", "clearInput", "clearInputIcon", "clearOnEdit", "color", "counter", "counterFormatter", "debounce", "disabled", "enterkeyhint", "errorText", "fill", "helperText", "inputmode", "label", "labelPlacement", "max", "maxlength", "min", "minlength", "mode", "multiple", "name", "pattern", "placeholder", "readonly", "required", "shape", "spellcheck", "step", "type", "value"] }, { kind: "component", type: i2.IonLabel, selector: "ion-label", inputs: ["color", "mode", "position"] }, { kind: "component", type: i2.IonSearchbar, selector: "ion-searchbar", inputs: ["animated", "autocapitalize", "autocomplete", "autocorrect", "cancelButtonIcon", "cancelButtonText", "clearIcon", "color", "debounce", "disabled", "enterkeyhint", "inputmode", "maxlength", "minlength", "mode", "name", "placeholder", "searchIcon", "showCancelButton", "showClearButton", "spellcheck", "type", "value"] }, { kind: "directive", type: i2.TextValueAccessor, selector: "ion-input:not([type=number]),ion-textarea,ion-searchbar" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "pipe", type: i1.SlicePipe, name: "slice" }, { kind: "pipe", type: BoldPrefix, name: "boldprefix" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponent, decorators: [{
            type: Component,
            args: [{ providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: IonicAutoCompleteComponent,
                            multi: true
                        }
                    ], selector: 'ionic-auto-complete', standalone: false, template: "<ng-template #defaultSelection\n    let-attrs=\"attrs\">\n    <ion-chip class=\"{{ attrs.removeButtonClasses }}\"\n        [color]=\"attrs.removeButtonColor\"\n        [outline]=\"true\">\n        <ion-icon *ngIf=\"frontIcon\"\n            [name]=\"frontIcon\"\n            [slot]=\"'start'\"\n            color=\"primary\"></ion-icon>\n\n        <ion-label>{{ attrs.label }}</ion-label>\n\n        <ion-icon *ngIf=\"attrs.removeButtonIcon\"\n            [name]=\"attrs.removeButtonIcon\"\n            [slot]=\"attrs.removeButtonSlot\"></ion-icon>\n    </ion-chip>\n</ng-template>\n\n<div *ngIf=\"multi\">\n    <div *ngFor=\"let item of selected\"\n        class=\"selected-items\"\n        (click)=\"removeItem(item)\">\n        <ng-template [ngTemplateOutlet]=\"selectionTemplate || defaultSelection\"\n            [ngTemplateOutletContext]=\"{\n                            attrs: {\n                              data:                item,\n                              label:               getLabel(item),\n                              removeButtonClasses: removeButtonClasses,\n                              removeButtonColor:   removeButtonColor,\n                              removeButtonIcon:    removeButtonIcon,\n                              removeButtonSlot:    removeButtonSlot\n                            }\n                         }\"></ng-template>\n    </div>\n</div>\n\n<ion-label *ngIf=\"label.length !== 0\"\n    [position]=\"labelPosition\">{{ label }}</ion-label>\n\n<ion-input #inputElem\n    [autocomplete]=\"autocomplete\"\n    [name]=\"name\"\n    (ionInput)=\"getItems($event)\"\n    (tap)=\"handleTap($event)\"\n    [formControl]=\"keywordControl\"\n    [placeholder]=\"autocompleteOptions.placeholder == null ? defaultOpts.placeholder : autocompleteOptions.placeholder\"\n    [type]=\"autocompleteOptions.type == null ? defaultOpts.type : autocompleteOptions.type\"\n    [clearOnEdit]=\"autocompleteOptions.clearOnEdit == null ? defaultOpts.clearOnEdit : autocompleteOptions.clearOnEdit\"\n    [clearInput]=\"autocompleteOptions.clearInput == null ? defaultOpts.clearInput : autocompleteOptions.clearInput\"\n    [color]=\"autocompleteOptions.color == null ? null : autocompleteOptions.color\"\n    [mode]=\"autocompleteOptions.mode == null ? defaultOpts.mode : autocompleteOptions.mode\"\n    [disabled]=\"disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected)\"\n    [ngClass]=\"{ 'hidden': !useIonInput, 'loading': isLoading }\"\n    [ngStyle]=\"styles.searchbar\"\n    (keydown.tab)=\"handleTabOut($event)\"\n    (keydown.shift.tab)=\"hideItemList()\"\n    (keyup.arrowDown)=\"highlightItem(-1)\"\n    (keyup.arrowUp)=\"highlightItem(1)\"\n    (keyup.enter)=\"handleSelectTap($event, suggestions[focusedOption])\"\n    (keyup.escape)=\"hideItemList()\"\n    (ionFocus)=\"onFocus($event)\"\n    (ionBlur)=\"onBlur($event)\"></ion-input>\n\n<ion-searchbar #searchbarElem\n    [autocomplete]=\"autocomplete\"\n    [name]=\"name\"\n    [animated]=\"autocompleteOptions.animated == null ? defaultOpts.animated : autocompleteOptions.animated\"\n    (ionInput)=\"getItems($event)\"\n    (tap)=\"handleTap($event)\"\n    [formControl]=\"keywordControl\"\n    [cancelButtonIcon]=\"autocompleteOptions.cancelButtonIcon == null ? defaultOpts.cancelButtonIcon : autocompleteOptions.cancelButtonIcon\"\n    [cancelButtonText]=\"autocompleteOptions.cancelButtonText == null ? defaultOpts.cancelButtonText : autocompleteOptions.cancelButtonText\"\n    [clearIcon]=\"autocompleteOptions.clearIcon == null ? defaultOpts.clearIcon : autocompleteOptions.clearIcon\"\n    [color]=\"autocompleteOptions.color == null ? null : autocompleteOptions.color\"\n    [showCancelButton]=\"autocompleteOptions.showCancelButton == null ?\n                                        (defaultOpts.showCancelButton ? 'always' : 'never') :\n                                        (autocompleteOptions.showCancelButton ? 'always' : 'never')\"\n    [debounce]=\"autocompleteOptions.debounce == null ? defaultOpts.debounce : autocompleteOptions.debounce\"\n    [placeholder]=\"autocompleteOptions.placeholder == null ? defaultOpts.placeholder : autocompleteOptions.placeholder\"\n    [autocorrect]=\"autocompleteOptions.autocorrect == null ? defaultOpts.autocorrect : autocompleteOptions.autocorrect\"\n    [mode]=\"autocompleteOptions.mode == null ? defaultOpts.mode : autocompleteOptions.mode\"\n    [searchIcon]=\"autocompleteOptions.searchIcon == null ? defaultOpts.searchIcon : autocompleteOptions.searchIcon\"\n    [spellcheck]=\"autocompleteOptions.spellcheck == null ? defaultOpts.spellcheck : autocompleteOptions.spellcheck\"\n    [type]=\"autocompleteOptions.type == null ? defaultOpts.type : autocompleteOptions.type\"\n    [ngClass]=\"{ 'hidden': useIonInput, 'loading': isLoading, 'disabled': disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected) }\"\n    [ngStyle]=\"styles.searchbar\"\n    (keydown.tab)=\"handleTabOut($event)\"\n    (keydown.shift.tab)=\"hideItemList()\"\n    (keyup.arrowDown)=\"highlightItem(-1)\"\n    (keyup.arrowUp)=\"highlightItem(1)\"\n    (keyup.enter)=\"handleSelectTap($event, suggestions[focusedOption])\"\n    (keyup.escape)=\"hideItemList()\"\n    (ionClear)=\"clickClear()\"\n    (ionFocus)=\"onFocus($event)\"\n    (ionBlur)=\"onBlur($event)\"></ion-searchbar>\n\n<ng-template #defaultTemplate\n    let-attrs=\"attrs\">\n    <span [innerHTML]='attrs.label | boldprefix:attrs.keyword'></span>\n</ng-template>\n\n<ng-template #defaultEmptyTemplate\n    let-attrs=\"attrs\"\n    class=\"ion-text-center\">\n    {{ autocompleteOptions.noItems }}\n</ng-template>\n\n<ng-template [ngTemplateOutlet]=\"listTemplate || defaultList\"\n    [ngTemplateOutletContext]=\"{\n                        attrs: {\n                            data:            suggestions,\n                            keyword:         keyword,\n                            maxResults:      maxResults,\n                            maxSelected:     maxSelected,\n                            selected:        selected,\n                            showSuggestions: showSuggestions\n                          }\n                        }\"></ng-template>\n\n<ng-template #defaultList\n    let-attrs=\"attrs\">\n    <ul *ngIf=\"!(disabled || (attrs.maxSelected !== null && attrs.selected.length >= attrs.maxSelected)) && attrs.data.length > 0 && attrs.showSuggestions\"\n        #itemList\n        [ngStyle]=\"listStyles()\">\n        <li *ngFor=\"let suggestion of attrs.data| slice:0 : attrs.maxResults; let index = index\"\n            [ngClass]=\"{ 'focus': focusedOption === index }\"\n            [ngStyle]=\"styles.listItem\"\n            (mouseenter)=\"focusedOption = index\"\n            (click)=\"handleSelectTap($event, suggestion)\"\n            (tap)=\"handleSelectTap($event, suggestion)\">\n            <ng-template [ngTemplateOutlet]=\"template || defaultTemplate\"\n                [ngTemplateOutletContext]=\"{\n                            attrs:{\n                              data:               suggestion,\n                              label:              getLabel(suggestion),\n                              keyword:            keyword,\n                              formValue:          getFormValue(suggestion),\n                              labelAttribute:     getLabel(suggestion),\n                              formValueAttribute: getFormValue(suggestion)\n                            }\n                         }\"></ng-template>\n        </li>\n    </ul>\n\n    <ul *ngIf=\"!isLoading && suggestions.length === 0 && showSuggestions\"\n        [ngStyle]=\"listStyles()\">\n        <li [ngStyle]=\"styles.listItem\">\n            <ng-template [ngTemplateOutlet]=\"emptyTemplate || defaultEmptyTemplate\"\n                [ngTemplateOutletContext]=\"{\n                        attrs:{\n                          keyword: keyword\n                        }\n                     }\"></ng-template>\n        </li>\n    </ul>\n</ng-template>", styles: ["ion-auto-complete{overflow:hidden!important;width:90vw;display:inline-block}ion-auto-complete ion-searchbar{padding:1px!important}ion-auto-complete .disabled input.searchbar-input{pointer-events:none;cursor:default}ion-auto-complete ul{position:absolute;width:90vw;margin-top:0;background:#fff;list-style-type:none;padding:0;left:16px;z-index:999;box-shadow:0 2px 2px #00000024,0 3px 1px -2px #0003,0 1px 5px #0000001f}ion-auto-complete ul li{padding:15px;border-bottom:1px solid #c1c1c1}ion-auto-complete ul li span{pointer-events:none}ion-auto-complete ul ion-auto-complete-item{height:40px;width:100%}ion-auto-complete ul li:last-child{border:none}ion-auto-complete ul li:focus,ion-auto-complete ul li.focus{cursor:pointer;background:#f1f1f1}ion-auto-complete .hidden{display:none}ion-auto-complete .loading input.searchbar-input{background:#fff url(/assets/loading.gif) no-repeat right 4px center;background-size:25px 25px}ion-auto-complete .searchbar-clear-button.sc-ion-searchbar-md{right:34px}ion-auto-complete .selected-items{float:left}\n"] }]
        }], ctorParameters: () => [], propDecorators: { alwaysShowList: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], autoFocusSuggestion: [{
                type: Input
            }], clearInvalidInput: [{
                type: Input
            }], disabled: [{
                type: Input
            }], emptyTemplate: [{
                type: Input
            }], exclude: [{
                type: Input
            }], frontIcon: [{
                type: Input
            }], hideListOnSelection: [{
                type: Input
            }], keyword: [{
                type: Input
            }], label: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], listTemplate: [{
                type: Input
            }], location: [{
                type: Input
            }], maxResults: [{
                type: Input
            }], maxSelected: [{
                type: Input
            }], multi: [{
                type: Input
            }], name: [{
                type: Input
            }], provider: [{
                type: Input
            }], removeButtonClasses: [{
                type: Input
            }], removeButtonColor: [{
                type: Input
            }], removeButtonIcon: [{
                type: Input
            }], removeButtonSlot: [{
                type: Input
            }], removeDuplicateSuggestions: [{
                type: Input
            }], selectionTemplate: [{
                type: Input
            }], selectOnTabOut: [{
                type: Input
            }], showResultsFirst: [{
                type: Input
            }], styles: [{
                type: Input
            }], template: [{
                type: Input
            }], useIonInput: [{
                type: Input
            }], autoFocus: [{
                type: Output
            }], autoBlur: [{
                type: Output
            }], blur: [{
                type: Output
            }], focus: [{
                type: Output
            }], ionAutoInput: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemsCleared: [{
                type: Output
            }], itemsHidden: [{
                type: Output
            }], itemRemoved: [{
                type: Output
            }], itemSelected: [{
                type: Output
            }], itemsShown: [{
                type: Output
            }], modelChange: [{
                type: Output
            }], searchbarElem: [{
                type: ViewChild,
                args: ['searchbarElem',
                    {
                        read: ElementRef
                    }]
            }], inputElem: [{
                type: ViewChild,
                args: ['inputElem',
                    {
                        read: ElementRef
                    }]
            }], itemList: [{
                type: ViewChild,
                args: ['itemList',
                    {
                        read: ElementRef
                    }]
            }], dataProvider: [{
                type: Input
            }], eager: [{
                type: Input
            }], options: [{
                type: Input
            }], model: [{
                type: Input
            }], showList: [{
                type: Input
            }], documentClickHandler: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class IonicAutoCompleteComponentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponentModule, declarations: [IonicAutoCompleteComponent], imports: [CommonModule,
            IonicModule,
            ReactiveFormsModule,
            BoldPrefix], exports: [IonicAutoCompleteComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponentModule, imports: [CommonModule,
            IonicModule,
            ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.0", ngImport: i0, type: IonicAutoCompleteComponentModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [IonicAutoCompleteComponent],
                    imports: [
                        CommonModule,
                        IonicModule,
                        ReactiveFormsModule,
                        BoldPrefix
                    ],
                    exports: [IonicAutoCompleteComponent]
                }]
        }] });

/*
 * Public API Surface of ionic-auto-complete
 */

/**
 * Generated bundle index. Do not edit.
 */

export { IonicAutoCompleteComponent, IonicAutoCompleteComponentModule };
//# sourceMappingURL=ionic-auto-complete.mjs.map
